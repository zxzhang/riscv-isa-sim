P_LOOP(16, {
  pd = ps1 + ps2;
})
