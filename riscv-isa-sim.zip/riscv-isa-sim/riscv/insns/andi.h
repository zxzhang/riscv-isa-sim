WRITE_RD(insn.i_imm() & RS1);
