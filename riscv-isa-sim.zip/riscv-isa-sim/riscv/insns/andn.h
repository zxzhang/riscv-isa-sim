require_either_extension(EXT_ZBB, EXT_ZBKB);
WRITE_RD(RS1 & ~RS2);
