require_extension(EXT_ZCA);
set_pc(pc + insn.rvc_j_imm());
