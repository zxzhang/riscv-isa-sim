require_extension(EXT_ZCB);
WRITE_RVC_RS1S(sext_xlen(~RVC_RS1S));
