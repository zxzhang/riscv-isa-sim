require_extension(EXT_ZCB);
require_extension(EXT_ZBB);
WRITE_RVC_RS1S((sreg_t)(int8_t)(RVC_RS1S));
