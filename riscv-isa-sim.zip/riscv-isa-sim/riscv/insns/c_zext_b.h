require_extension(EXT_ZCB);
WRITE_RVC_RS1S((reg_t)(uint8_t)(RVC_RS1S));
