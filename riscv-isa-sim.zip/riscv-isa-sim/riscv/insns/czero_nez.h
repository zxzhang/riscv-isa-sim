require_extension(EXT_ZICOND);
WRITE_RD(RS2 != 0 ? 0 : RS1);
