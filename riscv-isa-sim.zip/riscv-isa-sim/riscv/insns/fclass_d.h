require_either_extension('D', EXT_ZDINX);
require_fp;
WRITE_RD(f64_classify(FRS1_D));
