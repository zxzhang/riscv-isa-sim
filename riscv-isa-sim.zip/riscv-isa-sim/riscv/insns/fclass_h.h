require_either_extension(EXT_ZFH, EXT_ZHINX);
require_fp;
WRITE_RD(f16_classify(FRS1_H));
