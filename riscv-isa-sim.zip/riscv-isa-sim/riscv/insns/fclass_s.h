require_either_extension('F', EXT_ZFINX);
require_fp;
WRITE_RD(f32_classify(FRS1_F));
