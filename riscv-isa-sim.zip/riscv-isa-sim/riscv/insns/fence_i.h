MMU.flush_icache();
