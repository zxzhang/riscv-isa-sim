require_either_extension(EXT_ZFH, EXT_ZHINX);
require_fp;
WRITE_RD(f16_le(FRS1_H, FRS2_H));
set_fp_exceptions;
