require_extension('D');
require_extension(EXT_ZFA);
require_fp;
WRITE_RD(f64_le_quiet(FRS1_D, FRS2_D));
set_fp_exceptions;
