require_either_extension('F', EXT_ZFINX);
require_fp;
WRITE_RD(f32_lt(FRS1_F, FRS2_F));
set_fp_exceptions;
