require_extension(EXT_ZFH);
require_extension(EXT_ZFA);
require_fp;
WRITE_RD(f16_lt_quiet(FRS1_H, FRS2_H));
set_fp_exceptions;
