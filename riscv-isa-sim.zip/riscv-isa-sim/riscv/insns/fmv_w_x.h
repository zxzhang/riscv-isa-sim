require_extension('F');
require_fp;
WRITE_FRD(f32(RS1));
