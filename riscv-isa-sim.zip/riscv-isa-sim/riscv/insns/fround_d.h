require_extension('D');
require_extension(EXT_ZFA);
require_fp;
WRITE_FRD_D(f64_roundToInt(FRS1_D, RM, false));
set_fp_exceptions;
