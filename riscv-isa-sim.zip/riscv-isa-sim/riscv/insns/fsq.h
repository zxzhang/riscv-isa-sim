require_extension('Q');
require_fp;
MMU.store_float128(RS1 + insn.s_imm(), FRS2);
