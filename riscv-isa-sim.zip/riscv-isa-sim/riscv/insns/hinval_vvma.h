require_extension(EXT_SVINVAL);
#include "hfence_vvma.h"
